---
name: Enhancement request
about: To request an enhancement, please fill this form.
title: ''
labels: ''
assignees: ''

---

### Suggested enhancement



### Justification

Mbed TLS needs this because 

